const express = require('express');
const session = require('express-session');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

const app = express();
const db = new Database(path.join(__dirname, 'attendance.db'));
const PORT = process.env.PORT || 3000;

db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS students (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 student_code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, father_name TEXT DEFAULT '',
 roll_number TEXT DEFAULT '', class_name TEXT DEFAULT '', section TEXT DEFAULT '',
 phone TEXT DEFAULT '', guardian_phone TEXT DEFAULT '', address TEXT DEFAULT '',
 photo TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP, active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS attendance (
 id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL,
 attendance_date TEXT NOT NULL, attendance_time TEXT NOT NULL,
 marked_by TEXT DEFAULT 'admin', UNIQUE(student_id, attendance_date),
 FOREIGN KEY(student_id) REFERENCES students(id)
);
`);
const username = process.env.ADMIN_USERNAME || 'admin';
const password = process.env.ADMIN_PASSWORD || 'admin123';
if (!db.prepare('SELECT id FROM users WHERE username=?').get(username)) {
  db.prepare('INSERT INTO users(username,password_hash) VALUES(?,?)').run(username, bcrypt.hashSync(password, 10));
}

app.use(express.json({limit:'2mb'}));
app.use(express.urlencoded({extended:true}));
app.use(session({
 secret: process.env.SESSION_SECRET || 'replace-this-secret-before-deployment',
 resave:false, saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:8*60*60*1000}
}));
app.use(express.static(path.join(__dirname,'public')));

const auth = (req,res,next) => req.session.user ? next() : res.status(401).json({error:'Please log in first.'});
const today = () => new Date().toLocaleDateString('en-CA');
const nowTime = () => new Date().toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'});

app.post('/api/login',(req,res)=>{
 const {username,password}=req.body;
 const user=db.prepare('SELECT * FROM users WHERE username=?').get(username||'');
 if(!user || !bcrypt.compareSync(password||'',user.password_hash)) return res.status(401).json({error:'Incorrect username or password.'});
 req.session.user={username:user.username}; res.json({ok:true,username:user.username});
});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({loggedIn:!!req.session.user,username:req.session.user?.username||''}));

app.get('/api/dashboard',auth,(req,res)=>{
 const date=today();
 const total=db.prepare('SELECT COUNT(*) n FROM students WHERE active=1').get().n;
 const present=db.prepare('SELECT COUNT(*) n FROM attendance WHERE attendance_date=?').get(date).n;
 res.json({total,present,absent:Math.max(0,total-present),date});
});
app.get('/api/students',auth,(req,res)=>{
 const q=(req.query.q||'').trim();
 const rows=q ? db.prepare(`SELECT * FROM students WHERE active=1 AND (name LIKE ? OR student_code LIKE ? OR roll_number LIKE ? OR class_name LIKE ?) ORDER BY id DESC`).all(`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`)
 : db.prepare('SELECT * FROM students WHERE active=1 ORDER BY id DESC').all();
 res.json(rows);
});
app.post('/api/students',auth,(req,res)=>{
 const s=req.body;
 if(!s.name?.trim() || !s.student_code?.trim()) return res.status(400).json({error:'Student name and Student ID are required.'});
 try {
  const info=db.prepare(`INSERT INTO students(student_code,name,father_name,roll_number,class_name,section,phone,guardian_phone,address,photo)
   VALUES(@student_code,@name,@father_name,@roll_number,@class_name,@section,@phone,@guardian_phone,@address,@photo)`).run({
    student_code:s.student_code.trim(),name:s.name.trim(),father_name:s.father_name||'',roll_number:s.roll_number||'',
    class_name:s.class_name||'',section:s.section||'',phone:s.phone||'',guardian_phone:s.guardian_phone||'',
    address:s.address||'',photo:s.photo||''
   });
  res.json({ok:true,id:info.lastInsertRowid});
 } catch(e) {res.status(400).json({error:e.message.includes('UNIQUE')?'That Student ID already exists.':'Could not save student.'});}
});
app.get('/api/students/:code',auth,(req,res)=>{
 const s=db.prepare('SELECT * FROM students WHERE student_code=? AND active=1').get(req.params.code);
 if(!s) return res.status(404).json({error:'Student card not found.'});
 res.json(s);
});
app.delete('/api/students/:id',auth,(req,res)=>{
 db.prepare('UPDATE students SET active=0 WHERE id=?').run(req.params.id); res.json({ok:true});
});
app.post('/api/attendance',auth,(req,res)=>{
 const {student_code}=req.body;
 const s=db.prepare('SELECT * FROM students WHERE student_code=? AND active=1').get(student_code||'');
 if(!s) return res.status(404).json({error:'Student not found. Register this student first.'});
 const date=today(), time=nowTime();
 try {
  db.prepare('INSERT INTO attendance(student_id,attendance_date,attendance_time,marked_by) VALUES(?,?,?,?)')
   .run(s.id,date,time,req.session.user.username);
  res.json({ok:true,student:s,date,time});
 } catch(e) {
  if(e.message.includes('UNIQUE')) return res.status(409).json({error:'Attendance has already been marked for this student today.'});
  res.status(500).json({error:'Could not mark attendance.'});
 }
});
app.get('/api/attendance',auth,(req,res)=>{
 const date=req.query.date||today();
 const rows=db.prepare(`SELECT a.id,a.attendance_date,a.attendance_time,a.marked_by,
 s.student_code,s.name,s.roll_number,s.class_name,s.section
 FROM attendance a JOIN students s ON s.id=a.student_id
 WHERE a.attendance_date=? ORDER BY a.attendance_time DESC`).all(date);
 res.json(rows);
});
app.get('/api/reports.csv',auth,(req,res)=>{
 const date=req.query.date||today();
 const rows=db.prepare(`SELECT s.student_code,s.name,s.roll_number,s.class_name,s.section,
 CASE WHEN a.id IS NULL THEN 'ABSENT' ELSE 'PRESENT' END status,
 COALESCE(a.attendance_time,'') attendance_time
 FROM students s LEFT JOIN attendance a ON a.student_id=s.id AND a.attendance_date=?
 WHERE s.active=1 ORDER BY s.class_name,s.roll_number`).all(date);
 const esc=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
 const csv=[['Student ID','Name','Roll No','Class','Section','Status','Time'],...rows.map(r=>[r.student_code,r.name,r.roll_number,r.class_name,r.section,r.status,r.attendance_time])]
 .map(row=>row.map(esc).join(',')).join('\n');
 res.setHeader('Content-Type','text/csv; charset=utf-8');
 res.setHeader('Content-Disposition',`attachment; filename="attendance-${date}.csv"`);
 res.send('\uFEFF'+csv);
});

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Attendance system running at http://localhost:${PORT}`));

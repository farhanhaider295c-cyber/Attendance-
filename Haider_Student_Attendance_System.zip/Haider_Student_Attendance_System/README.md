# Haider Student Attendance System

A working QR-based student attendance web app. Admin scans the QR code on a student's ID card, reviews the student's profile, and manually confirms attendance.

## Requirements
- Node.js 18 or newer
- Internet connection for the QR scanner / QR generator browser libraries (the backend and database run locally)
- Camera permission. Browsers generally allow camera access on `http://localhost` or HTTPS.

## Run on Windows
1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP folder.
3. Open the extracted folder in VS Code.
4. Open Terminal in VS Code and run:

   ```bash
   npm install
   npm start
   ```

5. Open http://localhost:3000 in Chrome or Edge.
6. Sign in with:
   - Username: `admin`
   - Password: `admin123`

## First use
1. Open **Students** and add a student. Student ID must be unique, for example `STU-1001`.
2. Open **ID Card Studio**, select that student and print the front and back card. The QR code contains the student's unique ID.
3. Open **Scan ID Card**, press **Start camera**, and show the QR code on the card to the camera.
4. Check the displayed student details, then press **Mark Attendance**.
5. View records and export a daily CSV report.

You can also type a Student ID manually if a camera is unavailable.

## Important
- Scanning a card does NOT mark attendance. The admin must press **Mark Attendance**.
- A student can only be marked present once per date.
- The SQLite database is stored in `attendance.db` in this project folder.
- Change the default admin password and `SESSION_SECRET` before using this on a public server. The starter version is intended for a trusted local school network, not public internet deployment.
- Use HTTPS for camera access when hosted online.
- Student photos are currently entered as an image URL. For a production deployment, add secure image upload/storage, role permissions, backups, audit logs and HTTPS.
